# Security Specification: JANSEVAHELP-AI

## 1. Data Invariants
- `citizen_requests`: Public civic development requests submitted by citizens in their local language.
- Every citizen request must have valid text (<= 3000 chars), valid language, state, district, category, problem, and urgency.
- No PII is collected or stored (no phone numbers, personal emails, or national IDs).
- Citizen requests are append-only by public users; modifications/deletions are blocked to maintain immutable public civic audit trails.

## 2. The Dirty Dozen Attack Payloads
1. Request with 2MB spam string in `originalText` (Blocked by `<= 3000` length constraint).
2. Request with arbitrary HTML/script injection in `category` (Blocked by length and string validation).
3. Request missing `problem` or `urgency` (Blocked by `hasAll` and type validation).
4. Request injecting unknown keys e.g. `{ isAdmin: true }` (Blocked by `hasOnly`).
5. Request with negative or non-numeric `estimatedAffectedCount`.
6. Request tampering with someone else's request via `update` (Blocked: updates forbidden).
7. Request tampering via `delete` (Blocked: deletes forbidden).
8. Malicious document ID exceeding 128 characters or containing illegal path characters (Blocked by `isValidId`).
9. Request spoofing urgency to an unsupported value like "CriticalEmergencyCall911" (Blocked by enum check).
10. Blanket overwrite of the database root (Blocked by default-deny catch-all).
11. Unbounded batch write flood (Blocked by rule bounds and size constraints).
12. Shadow update attempting to modify request status directly (Blocked by update rejection).
