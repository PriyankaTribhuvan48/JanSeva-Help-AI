export type UrgencyLevel = 'Low' | 'Medium' | 'High';

export type RequestStatus = 'Under Review' | 'Hotspot Flagged' | 'Prioritized' | 'Verified';

export type CivicCategory = 
  | 'Roads'
  | 'Water'
  | 'Healthcare'
  | 'Education'
  | 'Electricity'
  | 'Sanitation'
  | 'Public Transport'
  | 'Digital Connectivity'
  | 'Other';

export interface CitizenRequest {
  id: string;
  originalText: string;
  language: string;
  state: string;
  district: string;
  locality?: string;
  category: CivicCategory | string;
  problem: string;
  urgency: UrgencyLevel;
  affectedGroup?: string;
  requestedSolution?: string;
  estimatedAffectedCount: number;
  source: 'text' | 'voice';
  status: RequestStatus;
  createdAt: string;
}

export interface HotspotData {
  id: string;
  district: string;
  state: string;
  category: string;
  requestCount: number;
  highUrgencyCount: number;
  mediumUrgencyCount: number;
  lowUrgencyCount: number;
  totalAffectedPopulation: number;
  infrastructureGapScore: number; // 0-100 from synthetic regional context
  volumeScore: number;            // 0-100
  urgencyScore: number;           // 0-100
  populationScore: number;        // 0-100
  gapScore: number;               // 0-100
  hotspotSignal: number;          // 0-100 combined weighted score
  sampleProblems: string[];
  affectedGroups: string[];
  languages: string[];
  latestTimestamp: string;
}

export interface AIRecommendation {
  id: string;
  district: string;
  state: string;
  category: string;
  hotspotSignal: number;
  detectedDevelopmentNeed: string;
  supportingEvidence: string;
  affectedGroups: string;
  recommendedProjectIdea: string;
  reasonForRecommendation: string;
  relevantLimitations: string;
  recommendedInterventions: string[];
  fundingSchemeAlignment?: string;
  generatedAt: string;
  advisoryDisclaimer: string;
}

export interface RegionalIndicator {
  baselinePopulation: number;
  infrastructureGapScores: Record<string, number>;
  dominantTerrain: string;
}
