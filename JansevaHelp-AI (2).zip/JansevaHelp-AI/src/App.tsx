import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Home } from './components/Home';
import { CitizenRequestForm } from './components/CitizenRequestForm';
import { LiveIntelligence } from './components/LiveIntelligence';
import { Hotspots } from './components/Hotspots';
import { Recommendations } from './components/Recommendations';
import { About } from './components/About';
import { CitizenRequest, HotspotData } from './types';
import { 
  subscribeToCitizenRequests, 
  seedInitialRequestsIfEmpty, 
  forceReseedRequests 
} from './services/firebase';
import { calculateHotspots } from './utils/hotspotCalculator';
import { SEED_CITIZEN_REQUESTS } from './data/seedRequests';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [requests, setRequests] = useState<CitizenRequest[]>([]);
  const [hotspots, setHotspots] = useState<HotspotData[]>([]);
  const [isReseeding, setIsReseeding] = useState(false);
  const [selectedHotspotForRec, setSelectedHotspotForRec] = useState<HotspotData | null>(null);
  const [prefillMarathi, setPrefillMarathi] = useState(false);
  const [targetDistrictFilter, setTargetDistrictFilter] = useState<string | undefined>(undefined);
  const [targetCategoryFilter, setTargetCategoryFilter] = useState<string | undefined>(undefined);

  // Initialize and subscribe to real-time Firestore updates
  useEffect(() => {
    // 1. Ensure initial seed requests exist
    seedInitialRequestsIfEmpty().catch((err) => {
      console.warn('Initial seed check error, will fall back if offline:', err);
    });

    // 2. Real-time Firestore listener
    const unsubscribe = subscribeToCitizenRequests(
      (items) => {
        if (items.length > 0) {
          setRequests(items);
          const computedHotspots = calculateHotspots(items);
          setHotspots(computedHotspots);
        } else {
          // Fallback to local seed items if database is totally fresh
          const localItems: CitizenRequest[] = SEED_CITIZEN_REQUESTS.map((s, idx) => ({
            ...s,
            id: `seed_local_${idx}`,
          }));
          setRequests(localItems);
          setHotspots(calculateHotspots(localItems));
        }
      },
      (err) => {
        console.warn('Firestore subscription fallback triggered:', err);
        // Fallback to local seed items
        const localItems: CitizenRequest[] = SEED_CITIZEN_REQUESTS.map((s, idx) => ({
          ...s,
          id: `seed_local_${idx}`,
        }));
        setRequests(localItems);
        setHotspots(calculateHotspots(localItems));
      }
    );

    return () => unsubscribe();
  }, []);

  // Recalculate hotspots whenever requests update
  useEffect(() => {
    if (requests.length > 0) {
      const computed = calculateHotspots(requests);
      setHotspots(computed);
    }
  }, [requests]);

  const handleReseed = async () => {
    setIsReseeding(true);
    try {
      await forceReseedRequests();
    } catch (e) {
      console.error('Failed to reseed:', e);
      // Fallback local refresh
      const localItems: CitizenRequest[] = SEED_CITIZEN_REQUESTS.map((s, idx) => ({
        ...s,
        id: `seed_local_${Date.now()}_${idx}`,
      }));
      setRequests(localItems);
      setHotspots(calculateHotspots(localItems));
    } finally {
      setIsReseeding(false);
    }
  };

  const handleQuickDemoMarathi = () => {
    setPrefillMarathi(true);
    setActiveTab('submit');
  };

  const handleSelectHotspotDistrict = (district: string, category: string) => {
    setTargetDistrictFilter(district);
    setTargetCategoryFilter(category);
    setActiveTab('hotspots');
  };

  const handleGenerateRecommendationFromHotspot = (hotspot: HotspotData) => {
    setSelectedHotspotForRec(hotspot);
    setActiveTab('recommendations');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-amber-100 selection:text-amber-900">
      {/* Top sticky navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'submit') setPrefillMarathi(false);
        }}
        requestCount={requests.length}
        onReseed={handleReseed}
        isReseeding={isReseeding}
      />

      {/* Main Page Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6">
        {activeTab === 'home' && (
          <Home
            setActiveTab={setActiveTab}
            requestCount={requests.length}
            hotspots={hotspots}
            onQuickDemoMarathi={handleQuickDemoMarathi}
          />
        )}

        {activeTab === 'submit' && (
          <CitizenRequestForm
            onSuccessNavigate={(tab) => setActiveTab(tab)}
            prefillMarathi={prefillMarathi}
          />
        )}

        {activeTab === 'intelligence' && (
          <LiveIntelligence
            requests={requests}
            onSelectHotspotDistrict={handleSelectHotspotDistrict}
          />
        )}

        {activeTab === 'hotspots' && (
          <Hotspots
            hotspots={hotspots}
            onGenerateRecommendation={handleGenerateRecommendationFromHotspot}
            selectedDistrictFilter={targetDistrictFilter}
            selectedCategoryFilter={targetCategoryFilter}
          />
        )}

        {activeTab === 'recommendations' && (
          <Recommendations
            hotspots={hotspots}
            selectedHotspot={selectedHotspotForRec}
            onSelectHotspot={(h) => setSelectedHotspotForRec(h)}
          />
        )}

        {activeTab === 'about' && <About />}
      </main>

      {/* Public Good Footer */}
      <footer className="border-t border-slate-200 bg-white mt-16 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-slate-900">JANSEVAHELP-AI</span>
            <span>•</span>
            <span>“Turning citizen voices into smarter development priorities.”</span>
          </div>
          <div className="flex items-center gap-3">
            <span>Build with AI: Code for Communities (Second Edition)</span>
            <span>•</span>
            <span className="font-semibold text-amber-600">Prototype Decision Support</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
