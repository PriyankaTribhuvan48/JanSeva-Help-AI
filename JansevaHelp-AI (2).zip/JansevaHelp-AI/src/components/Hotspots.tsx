import React, { useState, useMemo } from 'react';
import { 
  MapPin, 
  HelpCircle, 
  Sparkles, 
  TrendingUp, 
  Info, 
  ArrowRight, 
  Layers, 
  Sliders, 
  Filter, 
  CheckCircle,
  Database
} from 'lucide-react';
import { HotspotData } from '../types';
import { CIVIC_CATEGORIES } from '../data/geoData';

interface HotspotsProps {
  hotspots: HotspotData[];
  onGenerateRecommendation: (hotspot: HotspotData) => void;
  selectedDistrictFilter?: string;
  selectedCategoryFilter?: string;
}

export const Hotspots: React.FC<HotspotsProps> = ({
  hotspots,
  onGenerateRecommendation,
  selectedDistrictFilter,
  selectedCategoryFilter,
}) => {
  const [filterState, setFilterState] = useState<string>('All');
  const [filterCategory, setFilterCategory] = useState<string>(selectedCategoryFilter || 'All');
  const [searchDistrict, setSearchDistrict] = useState<string>(selectedDistrictFilter || '');
  const [expandedHotspotId, setExpandedHotspotId] = useState<string | null>(null);

  const statesList = useMemo(() => {
    return Array.from(new Set(hotspots.map((h) => h.state))).sort();
  }, [hotspots]);

  const filteredHotspots = useMemo(() => {
    return hotspots.filter((h) => {
      if (filterState !== 'All' && h.state !== filterState) return false;
      if (filterCategory !== 'All' && h.category !== filterCategory) return false;
      if (searchDistrict.trim()) {
        const query = searchDistrict.toLowerCase();
        if (!h.district.toLowerCase().includes(query)) return false;
      }
      return true;
    });
  }, [hotspots, filterState, filterCategory, searchDistrict]);

  return (
    <div className="space-y-8 py-4">
      {/* Header section */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold uppercase tracking-wider">
            Prototype Decision-Support Signal
          </span>
          <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-semibold">
            NOT an official government ranking
          </span>
          <span className="px-2.5 py-1 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-xs font-semibold flex items-center gap-1">
            <Database className="w-3 h-3" />
            Regional Indices: Synthetic / Demo Data
          </span>
        </div>

        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Development Demand Hotspots
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
          Transparent multi-factor prioritization synthesizing real-time citizen demand volume, urgency,
          impacted population, and baseline infrastructure gaps into an explainable 100-point signal.
        </p>
      </div>

      {/* Transparent Scoring Formula Card */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-950 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base text-white">
              Transparent 100-Point Scoring Logic (Application Engine)
            </h3>
          </div>
          <span className="text-xs text-amber-300 font-mono bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">
            Signal = Vol(35%) + Urg(25%) + Pop(25%) + Gap(15%)
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
          Core architectural principle: <strong>Gemini does NOT secretly assign numerical priorities</strong>.
          Gemini extracts civic meaning; the application layer computes this transparent mathematical index directly from verified data.
        </p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-1">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Request Volume</span>
              <span className="font-bold text-amber-400">35%</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Normalized frequency of citizen complaints in this district & category cluster.
            </p>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-1">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Urgency Index</span>
              <span className="font-bold text-rose-400">25%</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Ratio of high-severity submissions (health hazards, blocked school routes).
            </p>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-1">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Affected Population</span>
              <span className="font-bold text-sky-400">25%</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Log-scaled estimate of community beneficiaries and demographic scale.
            </p>
          </div>

          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-1">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Infrastructure Gap</span>
              <span className="font-bold text-emerald-400">15%</span>
            </div>
            <p className="text-[11px] text-slate-300">
              Synthetic baseline deficit indicator for sector availability in the district.
            </p>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 mr-2">
          <Filter className="w-3.5 h-3.5 text-amber-600" />
          <span>Filter Hotspots:</span>
        </div>

        {/* State select */}
        <select
          value={filterState}
          onChange={(e) => setFilterState(e.target.value)}
          className="text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none"
        >
          <option value="All">All States ({statesList.length})</option>
          {statesList.map((st) => (
            <option key={st} value={st}>
              {st}
            </option>
          ))}
        </select>

        {/* Category select */}
        <select
          value={filterCategory}
          onChange={(e) => setFilterCategory(e.target.value)}
          className="text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none"
        >
          <option value="All">All Categories</option>
          {CIVIC_CATEGORIES.map((cat) => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>

        {/* Search district */}
        <input
          type="text"
          value={searchDistrict}
          onChange={(e) => setSearchDistrict(e.target.value)}
          placeholder="Filter by district name..."
          className="text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:outline-none ml-auto"
        />
      </div>

      {/* Hotspots Grid / Cards */}
      <div className="space-y-4">
        {filteredHotspots.length === 0 ? (
          <div className="bg-white p-12 text-center rounded-3xl border border-slate-200 text-slate-400 text-sm">
            No hotspots match your filter criteria.
          </div>
        ) : (
          filteredHotspots.map((hotspot, idx) => {
            const isTopSignal = idx === 0;
            const isExpanded = expandedHotspotId === hotspot.id;

            return (
              <div
                key={hotspot.id}
                className={`bg-white rounded-3xl border transition-all shadow-sm hover:shadow-md ${
                  isTopSignal
                    ? 'border-amber-400/80 ring-1 ring-amber-400/20'
                    : 'border-slate-200'
                }`}
              >
                <div className="p-6 sm:p-7 space-y-5">
                  {/* Top Bar: Location, Category, and Score */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center">
                          #{idx + 1}
                        </span>
                        <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                          {hotspot.state}
                        </span>
                        <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                          {hotspot.category}
                        </span>
                        {isTopSignal && (
                          <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-rose-100 text-rose-800 animate-pulse">
                            Primary Demand Cluster
                          </span>
                        )}
                      </div>
                      <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                        {hotspot.district}
                      </h3>
                    </div>

                    {/* Hotspot Signal Score Badge */}
                    <div className="flex items-center gap-4 self-start sm:self-auto bg-slate-50 sm:bg-transparent p-3 sm:p-0 rounded-2xl">
                      <div className="text-right">
                        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                          Hotspot Signal
                        </div>
                        <div className="text-3xl font-black text-slate-900 flex items-baseline justify-end gap-1">
                          <span className={hotspot.hotspotSignal >= 75 ? 'text-rose-600' : 'text-amber-600'}>
                            {hotspot.hotspotSignal}
                          </span>
                          <span className="text-xs text-slate-400 font-semibold">/100</span>
                        </div>
                      </div>

                      {/* Recommend Button */}
                      <button
                        onClick={() => onGenerateRecommendation(hotspot)}
                        className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-sm transition-all hover:scale-[1.02]"
                      >
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>AI Recommendation →</span>
                      </button>
                    </div>
                  </div>

                  {/* Score Breakdown Progress Bars (Transparent Components) */}
                  <div className="space-y-2 pt-2">
                    <div className="text-xs font-bold text-slate-500 flex items-center justify-between">
                      <span>Formula Breakdown Components:</span>
                      <button
                        onClick={() => setExpandedHotspotId(isExpanded ? null : hotspot.id)}
                        className="text-amber-700 hover:text-amber-800 font-medium"
                      >
                        {isExpanded ? 'Hide Evidence Details' : 'Show Supporting Evidence & Math'}
                      </button>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                      {/* Volume */}
                      <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <div className="flex justify-between text-[11px] text-slate-600">
                          <span>Volume (35%)</span>
                          <span className="font-bold text-slate-900">{hotspot.volumeScore}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-amber-500 h-full rounded-full"
                            style={{ width: `${hotspot.volumeScore}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-slate-400">{hotspot.requestCount} requests</span>
                      </div>

                      {/* Urgency */}
                      <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <div className="flex justify-between text-[11px] text-slate-600">
                          <span>Urgency (25%)</span>
                          <span className="font-bold text-slate-900">{hotspot.urgencyScore}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-rose-500 h-full rounded-full"
                            style={{ width: `${hotspot.urgencyScore}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-slate-400">{hotspot.highUrgencyCount} high severity</span>
                      </div>

                      {/* Population */}
                      <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <div className="flex justify-between text-[11px] text-slate-600">
                          <span>Population (25%)</span>
                          <span className="font-bold text-slate-900">{hotspot.populationScore}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-sky-500 h-full rounded-full"
                            style={{ width: `${hotspot.populationScore}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-slate-400">~{hotspot.totalAffectedPopulation.toLocaleString('en-IN')} pop</span>
                      </div>

                      {/* Gap */}
                      <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <div className="flex justify-between text-[11px] text-slate-600">
                          <span>Baseline Gap (15%)</span>
                          <span className="font-bold text-slate-900">{hotspot.gapScore}</span>
                        </div>
                        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-emerald-500 h-full rounded-full"
                            style={{ width: `${hotspot.gapScore}%` }}
                          />
                        </div>
                        <span className="text-[10px] text-slate-400">Synthetic Regional Index</span>
                      </div>
                    </div>
                  </div>

                  {/* Expanded Supporting Evidence Details */}
                  {isExpanded && (
                    <div className="pt-4 border-t border-slate-100 space-y-3 text-xs bg-slate-50/50 p-4 rounded-2xl animate-in fade-in">
                      <div className="font-bold text-slate-900">
                        Supporting Evidence Surfaced from Citizen Voice:
                      </div>

                      <div className="space-y-1.5">
                        {hotspot.sampleProblems.map((prob, pIdx) => (
                          <div key={pIdx} className="flex items-start gap-2 text-slate-700 bg-white p-2.5 rounded-lg border border-slate-200">
                            <span className="text-amber-500 font-bold">•</span>
                            <span>"{prob}"</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-[11px] text-slate-500">
                        <div>
                          <strong>Key Stakeholders:</strong>{' '}
                          {hotspot.affectedGroups.join(', ') || 'Rural residents, school children, daily commuters'}
                        </div>
                        <div>
                          <strong>Languages Represented:</strong>{' '}
                          {hotspot.languages.join(', ')}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
