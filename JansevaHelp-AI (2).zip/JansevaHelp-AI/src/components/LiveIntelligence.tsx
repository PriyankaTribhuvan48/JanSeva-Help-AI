import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  Activity, 
  Users, 
  AlertTriangle, 
  MapPin, 
  Clock, 
  Filter, 
  ChevronDown, 
  ChevronUp, 
  Search, 
  Layers, 
  Volume2, 
  Sparkles, 
  Radio
} from 'lucide-react';
import { CitizenRequest } from '../types';
import { CATEGORY_ICONS_AND_COLORS, CIVIC_CATEGORIES } from '../data/geoData';

interface LiveIntelligenceProps {
  requests: CitizenRequest[];
  onSelectHotspotDistrict?: (district: string, category: string) => void;
}

export const LiveIntelligence: React.FC<LiveIntelligenceProps> = ({
  requests,
  onSelectHotspotDistrict,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedState, setSelectedState] = useState<string>('All');
  const [selectedUrgency, setSelectedUrgency] = useState<string>('All');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [expandedRequestId, setExpandedRequestId] = useState<string | null>(null);

  // Compute headline stats
  const totalRequests = requests.length;
  const highUrgencyCount = requests.filter((r) => r.urgency === 'High').length;
  const totalPeopleAffected = requests.reduce(
    (sum, r) => sum + (r.estimatedAffectedCount || 1000),
    0
  );

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const req of requests) {
      counts[req.category] = (counts[req.category] || 0) + 1;
    }
    return counts;
  }, [requests]);

  const topCategory = useMemo(() => {
    const entries = Object.entries(categoryCounts);
    if (entries.length === 0) return { category: 'N/A', count: 0 };
    entries.sort((a, b) => b[1] - a[1]);
    return { category: entries[0][0], count: entries[0][1] };
  }, [categoryCounts]);

  // District counts
  const districtCounts = useMemo(() => {
    const counts: Record<string, { count: number; state: string }> = {};
    for (const req of requests) {
      if (!counts[req.district]) {
        counts[req.district] = { count: 0, state: req.state };
      }
      counts[req.district].count += 1;
    }
    return counts;
  }, [requests]);

  const topDistrict = useMemo(() => {
    const entries = Object.entries(districtCounts);
    if (entries.length === 0) return { district: 'N/A', state: '', count: 0 };
    entries.sort((a, b) => b[1].count - a[1].count);
    return {
      district: entries[0][0],
      state: entries[0][1].state,
      count: entries[0][1].count,
    };
  }, [districtCounts]);

  // Language breakdown
  const languageCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const req of requests) {
      counts[req.language] = (counts[req.language] || 0) + 1;
    }
    return counts;
  }, [requests]);

  // State breakdown
  const stateCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const req of requests) {
      counts[req.state] = (counts[req.state] || 0) + 1;
    }
    return counts;
  }, [requests]);

  // Available filters
  const uniqueStates = useMemo(() => {
    return Array.from(new Set(requests.map((r) => r.state))).sort();
  }, [requests]);

  const uniqueLanguages = useMemo(() => {
    return Array.from(new Set(requests.map((r) => r.language))).sort();
  }, [requests]);

  // Filtered requests for the live feed
  const filteredRequests = useMemo(() => {
    return requests.filter((r) => {
      if (selectedCategory !== 'All' && r.category !== selectedCategory) return false;
      if (selectedState !== 'All' && r.state !== selectedState) return false;
      if (selectedUrgency !== 'All' && r.urgency !== selectedUrgency) return false;
      if (selectedLanguage !== 'All' && r.language !== selectedLanguage) return false;
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const textMatch = r.originalText.toLowerCase().includes(query);
        const problemMatch = r.problem.toLowerCase().includes(query);
        const distMatch = r.district.toLowerCase().includes(query);
        const locMatch = (r.locality || '').toLowerCase().includes(query);
        if (!textMatch && !problemMatch && !distMatch && !locMatch) return false;
      }
      return true;
    });
  }, [requests, selectedCategory, selectedState, selectedUrgency, selectedLanguage, searchTerm]);

  const formatTimestamp = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      });
    } catch {
      return 'Just now';
    }
  };

  return (
    <div className="space-y-8 py-4">
      {/* Header section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold">
            <Radio className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
            <span>Firestore Real-Time Listener Active (Zero Manual Refresh Required)</span>
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
            Live Development Intelligence
          </h1>
          <p className="text-sm text-slate-600">
            Real-time multi-state aggregation of citizen voice and structured civic demand.
          </p>
        </div>
      </div>

      {/* Headline Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Requests */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Total Requests</span>
            <Layers className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {totalRequests}
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            Across {Object.keys(districtCounts).length} Indian districts
          </p>
        </div>

        {/* High-Urgency Requests */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>High-Urgency Needs</span>
            <AlertTriangle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-3xl font-extrabold text-rose-600">
            {highUrgencyCount}
          </div>
          <p className="text-[11px] text-rose-600/90 font-medium">
            {totalRequests > 0 ? Math.round((highUrgencyCount / totalRequests) * 100) : 0}% of all submissions
          </p>
        </div>

        {/* Estimated People Affected */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2 col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Estimated Affected</span>
            <Users className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {totalPeopleAffected > 1000 ? `${(totalPeopleAffected / 1000).toFixed(1)}k` : totalPeopleAffected}
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            Community population impacted
          </p>
        </div>

        {/* Top Development Category */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Top Category</span>
            <BarChart3 className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-xl font-bold text-slate-900 truncate">
            {topCategory.category}
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            {topCategory.count} citizen submissions
          </p>
        </div>

        {/* Top Demand District */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2 col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Top Demand District</span>
            <MapPin className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-xl font-bold text-slate-900 truncate">
            {topDistrict.district}
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            {topDistrict.state} • {topDistrict.count} requests
          </p>
        </div>
      </div>

      {/* Multi-Dimensional Aggregations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Aggregation Chart */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">Demand by Category</h3>
            <span className="text-xs text-slate-500 font-medium">{CIVIC_CATEGORIES.length} sectors</span>
          </div>

          <div className="space-y-3">
            {CIVIC_CATEGORIES.map((cat) => {
              const count = categoryCounts[cat] || 0;
              const pct = totalRequests > 0 ? Math.round((count / totalRequests) * 100) : 0;
              const style = CATEGORY_ICONS_AND_COLORS[cat] || CATEGORY_ICONS_AND_COLORS['Other'];
              return (
                <div key={cat} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-700">{cat}</span>
                    <span className="font-bold text-slate-900">
                      {count} <span className="text-slate-400 font-normal">({pct}%)</span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Language Aggregation */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-slate-900">Language Representation</h3>
              <span className="text-xs text-amber-700 bg-amber-50 px-2 py-0.5 rounded font-semibold">
                Multilingual AI
              </span>
            </div>
            <p className="text-xs text-slate-500 mb-4 leading-relaxed">
              Gemini understands and normalizes requests across native Indian languages without losing the original wording.
            </p>

            <div className="space-y-3">
              {Object.entries(languageCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([lang, count]) => {
                  const pct = totalRequests > 0 ? Math.round((count / totalRequests) * 100) : 0;
                  return (
                    <div key={lang} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold text-slate-800">{lang}</span>
                        <span className="font-bold text-slate-900">
                          {count} <span className="text-slate-400 font-normal">({pct}%)</span>
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Marathi, Hindi & English working</span>
            <span className="text-indigo-600 font-semibold">Extensible schema</span>
          </div>
        </div>

        {/* State Distribution */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-base font-bold text-slate-900">State Demand Clustering</h3>
              <span className="text-xs text-slate-500 font-semibold">{uniqueStates.length} states</span>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Geographic footprint across India. Not limited to any single urban hub.
            </p>

            <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
              {Object.entries(stateCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([st, count]) => {
                  return (
                    <div
                      key={st}
                      className="flex items-center justify-between p-2 rounded-xl bg-slate-50 hover:bg-slate-100 transition text-xs"
                    >
                      <span className="font-semibold text-slate-800">{st}</span>
                      <span className="font-bold px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-900">
                        {count} requests
                      </span>
                    </div>
                  );
                })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 text-[11px] text-slate-500">
            State → District → Locality Data Hierarchy
          </div>
        </div>
      </div>

      {/* LIVE ACTIVITY FEED */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Feed Header & Filters */}
        <div className="p-6 border-b border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <h2 className="text-lg font-bold text-slate-900">
                  Real-Time Citizen Activity Feed
                </h2>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Anonymous stream • Zero PII • Formatted as: Time • State • District • Category • Language • Urgency
              </p>
            </div>
            <div className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-100 text-slate-700">
              Showing {filteredRequests.length} of {requests.length} submissions
            </div>
          </div>

          {/* Filter Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
            {/* Search input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search problem, district..."
                className="w-full text-xs pl-8 pr-3 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            {/* Category filter */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="text-xs font-medium rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-slate-800 focus:bg-white focus:outline-none"
            >
              <option value="All">All Categories</option>
              {CIVIC_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            {/* State filter */}
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="text-xs font-medium rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-slate-800 focus:bg-white focus:outline-none"
            >
              <option value="All">All States</option>
              {uniqueStates.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>

            {/* Urgency filter */}
            <select
              value={selectedUrgency}
              onChange={(e) => setSelectedUrgency(e.target.value)}
              className="text-xs font-medium rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-slate-800 focus:bg-white focus:outline-none"
            >
              <option value="All">All Urgency</option>
              <option value="High">High Urgency</option>
              <option value="Medium">Medium Urgency</option>
              <option value="Low">Low Urgency</option>
            </select>

            {/* Language filter */}
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="text-xs font-medium rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-slate-800 focus:bg-white focus:outline-none"
            >
              <option value="All">All Languages</option>
              {uniqueLanguages.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Activity list */}
        <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
          {filteredRequests.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-sm">
              No citizen requests match the selected filter criteria.
            </div>
          ) : (
            filteredRequests.map((req) => {
              const isExpanded = expandedRequestId === req.id;
              const isHigh = req.urgency === 'High';
              return (
                <div
                  key={req.id}
                  className="p-4 sm:p-5 hover:bg-slate-50/70 transition space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    {/* Activity Feed Schema: Time • State • District • Category • Language • Urgency */}
                    <div className="flex flex-wrap items-center gap-2 text-xs">
                      <span className="font-mono text-slate-400 font-semibold flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-400" />
                        {formatTimestamp(req.createdAt)}
                      </span>
                      <span className="text-slate-300">•</span>
                      <span className="font-bold text-slate-900">{req.state}</span>
                      <span className="text-slate-300">•</span>
                      <span className="font-semibold text-slate-800">{req.district}</span>
                      <span className="text-slate-300">•</span>
                      <span className="px-2 py-0.5 rounded-md font-bold bg-amber-50 text-amber-800 border border-amber-200">
                        {req.category}
                      </span>
                      <span className="text-slate-300">•</span>
                      <span className="px-2 py-0.5 rounded-md font-medium bg-slate-100 text-slate-700">
                        {req.language}
                      </span>
                      <span className="text-slate-300">•</span>
                      <span
                        className={`px-2 py-0.5 rounded-md font-bold text-[11px] ${
                          isHigh
                            ? 'bg-rose-100 text-rose-800'
                            : req.urgency === 'Medium'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-200 text-slate-800'
                        }`}
                      >
                        {req.urgency}
                      </span>
                    </div>

                    {/* Expand/Collapse details toggle */}
                    <div className="flex items-center gap-2 self-end sm:self-auto">
                      {onSelectHotspotDistrict && (
                        <button
                          onClick={() => onSelectHotspotDistrict(req.district, req.category)}
                          className="text-[11px] font-semibold text-amber-700 hover:text-amber-800 bg-amber-50 hover:bg-amber-100 px-2 py-1 rounded transition"
                        >
                          View Hotspot →
                        </button>
                      )}
                      <button
                        onClick={() => setExpandedRequestId(isExpanded ? null : req.id)}
                        className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-medium"
                      >
                        <span>{isExpanded ? 'Hide Details' : 'Dual View'}</span>
                        {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* Summary Problem Line */}
                  <p className="text-xs sm:text-sm text-slate-700 font-medium line-clamp-1">
                    {req.problem || req.originalText}
                  </p>

                  {/* Expanded Dual-Preservation View (Original Voice + AI Structured) */}
                  {isExpanded && (
                    <div className="pt-3 grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-slate-100 text-xs">
                      {/* Left: Original Citizen Input */}
                      <div className="bg-amber-50/50 p-3.5 rounded-xl border border-amber-200/60 space-y-1.5">
                        <div className="font-bold text-amber-900 flex items-center gap-1.5">
                          <Volume2 className="w-3.5 h-3.5 text-amber-700" />
                          <span>Original Citizen Voice ({req.language})</span>
                        </div>
                        <p className="italic text-slate-800 text-xs leading-relaxed bg-white/70 p-2.5 rounded-lg border border-amber-100">
                          "{req.originalText}"
                        </p>
                        <div className="text-[10px] text-amber-800/80 flex justify-between pt-1">
                          <span>Source: {req.source === 'voice' ? '🎙️ Voice' : '⌨️ Text'}</span>
                          <span>Locality: {req.locality || 'Gram Panchayat'}</span>
                        </div>
                      </div>

                      {/* Right: Structured AI Extraction */}
                      <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-orange-600" />
                          <span>Structured Civic Extraction (Gemini)</span>
                        </div>
                        <div className="space-y-1 text-[11px] text-slate-700">
                          <div>
                            <strong>Core Problem:</strong> {req.problem}
                          </div>
                          <div>
                            <strong>Affected Cohort:</strong> {req.affectedGroup || 'Community residents'}
                          </div>
                          <div>
                            <strong>Requested Solution:</strong> {req.requestedSolution || 'Infrastructure repair & assessment'}
                          </div>
                          <div>
                            <strong>Impact Scale:</strong> ~{(req.estimatedAffectedCount || 1000).toLocaleString('en-IN')} citizens
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
