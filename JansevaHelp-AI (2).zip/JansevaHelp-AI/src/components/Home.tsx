import React from 'react';
import { 
  ArrowRight, 
  Mic, 
  Sparkles, 
  Layers, 
  MapPin, 
  TrendingUp, 
  ShieldCheck, 
  CheckCircle2, 
  Globe2, 
  Activity, 
  AlertTriangle,
  FileText
} from 'lucide-react';
import { HotspotData } from '../types';

interface HomeProps {
  setActiveTab: (tab: string) => void;
  requestCount: number;
  hotspots: HotspotData[];
  onQuickDemoMarathi: () => void;
}

export const Home: React.FC<HomeProps> = ({
  setActiveTab,
  requestCount,
  hotspots,
  onQuickDemoMarathi,
}) => {
  return (
    <div className="space-y-16 py-8">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white p-8 md:p-14 border border-slate-800 shadow-2xl">
        {/* Subtle decorative background blur */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 rounded-full bg-amber-500/15 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 rounded-full bg-indigo-500/15 blur-3xl pointer-events-none" />

        <div className="relative max-w-4xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/80 text-amber-300 text-xs font-semibold uppercase tracking-wider backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Prototype for Build with AI: Code for Communities • Innovation</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white leading-tight">
            JANSEVAHELP<span className="text-amber-400">-AI</span>
          </h1>

          <p className="text-xl sm:text-2xl font-medium text-amber-100/90 italic max-w-2xl mx-auto">
            “Turning citizen voices into smarter development priorities.”
          </p>

          <p className="text-sm sm:text-base font-medium text-slate-300 tracking-wide">
            Multilingual • AI-powered • Real-time • Built for India
          </p>

          <p className="text-slate-400 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            A decision-support layer for citizens, local administrators, and policymakers.
            Converting scattered multilingual voice and text requests into structured geographic intelligence
            and transparent development priorities.
          </p>

          {/* Primary Action Buttons */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => setActiveTab('submit')}
              className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm sm:text-base shadow-lg shadow-amber-500/25 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Mic className="w-5 h-5" />
              <span>Submit a Request</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>

            <button
              onClick={() => setActiveTab('intelligence')}
              className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm sm:text-base border border-slate-700 transition-all hover:scale-[1.02]"
            >
              <Activity className="w-5 h-5 text-emerald-400" />
              <span>View Live Intelligence</span>
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-slate-700 text-amber-300">
                {requestCount} live
              </span>
            </button>
          </div>

          {/* 1-Click Quick Demo prompt */}
          <div className="pt-2">
            <button
              onClick={onQuickDemoMarathi}
              className="inline-flex items-center gap-2 text-xs text-amber-300/90 hover:text-amber-200 underline underline-offset-4 decoration-amber-400/50"
            >
              <span>⚡ Try the exact Marathi Village Road Demo Flow (Ahmednagar)</span>
            </button>
          </div>
        </div>
      </section>

      {/* Visual Pipeline Flow Diagram */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center space-y-2 mb-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            The Core Architecture Pipeline
          </h2>
          <p className="text-slate-600 text-sm max-w-2xl mx-auto">
            Citizen request → Google Gemini → Structured data → Aggregation → Hotspots + Priority Signals → Explainable Recommendations
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 relative">
          {/* Step 1 */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                1
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Citizen Request</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Multilingual submission via voice or text in Marathi, Hindi, English, Gujarati, etc. No forced forms.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-[11px] font-semibold text-amber-700">
              <Mic className="w-3.5 h-3.5 mr-1" />
              <span>Voice + Text</span>
            </div>
          </div>

          {/* Step 2 */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-700 flex items-center justify-center font-bold">
                2
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Gemini AI Layer</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Extracts meaning: language, category, location, urgency, and affected demographic group.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-[11px] font-semibold text-orange-700">
              <Sparkles className="w-3.5 h-3.5 mr-1" />
              <span>Understanding</span>
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                3
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Structured Data</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Preserves original citizen voice while normalizing data schema for cross-language comparison.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-[11px] font-semibold text-blue-700">
              <FileText className="w-3.5 h-3.5 mr-1" />
              <span>Immutable Record</span>
            </div>
          </div>

          {/* Step 4 */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                4
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Real-time Sync</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Firestore real-time listeners trigger instant dashboard refresh and district aggregations.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-[11px] font-semibold text-emerald-700">
              <Layers className="w-3.5 h-3.5 mr-1" />
              <span>Firestore Sync</span>
            </div>
          </div>

          {/* Step 5 */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                5
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Hotspots Signal</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                100-point transparent formula: Volume (35%), Urgency (25%), Population (25%), Gap (15%).
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-[11px] font-semibold text-purple-700">
              <MapPin className="w-3.5 h-3.5 mr-1" />
              <span>Decision Support</span>
            </div>
          </div>

          {/* Step 6 */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                6
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Recommendations</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Explainable project proposals with supporting citizen evidence, scheme alignment, and human oversight.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-[11px] font-semibold text-indigo-700">
              <ShieldCheck className="w-3.5 h-3.5 mr-1" />
              <span>Human in Loop</span>
            </div>
          </div>
        </div>
      </section>

      {/* The 4 Core Problems We Solve */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="rounded-3xl bg-slate-100/70 border border-slate-200/80 p-8 sm:p-10">
          <div className="max-w-3xl mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-600">The Problem Space</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
              Why Traditional Civic Portals Fail Communities
            </h2>
            <p className="text-slate-600 text-sm mt-2">
              The problem is not collecting more complaints in bureaucratic silos. The goal is turning scattered feedback into comparable, geographic, and actionable development intelligence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2.5">
              <div className="w-8 h-8 rounded-lg bg-red-100 text-red-700 flex items-center justify-center font-bold text-sm">
                A
              </div>
              <h3 className="font-bold text-slate-900 text-base">FRAGMENTED</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Citizen requests sit scattered across paper registers, WhatsApp groups, grievance helplines, and taluka desks without unified aggregation.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-sm">
                B
              </div>
              <h3 className="font-bold text-slate-900 text-base">UNSTRUCTURED</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Dozens of Indian languages, colloquial dialects, and free-text narratives make it nearly impossible for district planners to compare needs.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-sm">
                C
              </div>
              <h3 className="font-bold text-slate-900 text-base">DISCONNECTED</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Raw complaints cannot easily be cross-referenced with baseline infrastructure deficits, demographic vulnerability, and scheme budgets.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-2.5">
              <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-sm">
                D
              </div>
              <h3 className="font-bold text-slate-900 text-base">UNPRIORITIZED</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Decision-makers lack a single, explainable view of where urgent civic bottlenecks cluster, resulting in reactive rather than systemic spending.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Snapshot Preview of Top Hotspot Signals */}
      {hotspots.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600">Emerging Signals</span>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                Top Development Demand Hotspots
              </h2>
              <p className="text-xs text-slate-500">
                Prototype Decision-Support Signals calculated dynamically from active citizen submissions.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('hotspots')}
              className="text-sm font-semibold text-amber-700 hover:text-amber-800 flex items-center gap-1"
            >
              <span>View All Hotspots</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {hotspots.slice(0, 3).map((hotspot) => (
              <div
                key={hotspot.id}
                onClick={() => setActiveTab('hotspots')}
                className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:border-amber-300 hover:shadow-md transition cursor-pointer group space-y-4"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-slate-100 text-slate-700">
                    {hotspot.state}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-slate-500 font-medium">Signal:</span>
                    <span className="text-base font-extrabold text-amber-600 group-hover:scale-110 transition">
                      {hotspot.hotspotSignal}
                    </span>
                    <span className="text-[10px] text-slate-400">/100</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-amber-700 transition">
                    {hotspot.district}
                  </h3>
                  <p className="text-sm font-semibold text-slate-600">
                    Category: {hotspot.category}
                  </p>
                </div>

                <div className="space-y-1.5 pt-2 border-t border-slate-100 text-xs text-slate-600">
                  <div className="flex justify-between">
                    <span>Citizen Requests:</span>
                    <span className="font-semibold text-slate-900">{hotspot.requestCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>High Urgency:</span>
                    <span className="font-semibold text-rose-600">{hotspot.highUrgencyCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Estimated Affected:</span>
                    <span className="font-semibold text-slate-900">{hotspot.totalAffectedPopulation.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-amber-500 to-rose-500 h-full rounded-full"
                    style={{ width: `${hotspot.hotspotSignal}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Built for India Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-10 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
              <Globe2 className="w-4 h-4" />
              <span>Designed for India — Not One City</span>
            </div>
            <h3 className="text-2xl font-bold tracking-tight text-white">
              State → District → Locality Scalable Hierarchy
            </h3>
            <p className="text-slate-300 text-sm leading-relaxed">
              Tested across 12+ states including Maharashtra, Assam, Bihar, Gujarat, Karnataka, Madhya Pradesh,
              Odisha, Rajasthan, Tamil Nadu, Telangana, Uttar Pradesh, and West Bengal. Works across Marathi, Hindi, English, and regional vernaculars.
            </p>
          </div>
          <button
            onClick={() => setActiveTab('about')}
            className="whitespace-nowrap px-6 py-3 rounded-xl bg-white text-slate-950 font-bold text-sm hover:bg-slate-100 transition shadow-lg"
          >
            Digital Public Good Principles →
          </button>
        </div>
      </section>
    </div>
  );
};
