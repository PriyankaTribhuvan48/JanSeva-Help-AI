import React from 'react';
import { 
  ShieldCheck, 
  Globe2, 
  Layers, 
  Sparkles, 
  UserCheck, 
  Eye, 
  Code2, 
  HelpCircle,
  FileCheck,
  Building2,
  AlertTriangle
} from 'lucide-react';

export const About: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-12 py-4">
      {/* Header */}
      <div className="space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold uppercase tracking-wider">
          <span>Build with AI: Code for Communities — Second Edition • Theme: Innovation</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          About JANSEVAHELP<span className="text-amber-600">-AI</span>
        </h1>
        <p className="text-base text-slate-600 leading-relaxed font-medium">
          “Turning citizen voices into smarter development priorities.”
        </p>
      </div>

      {/* Core Principle Callout */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 border border-slate-800 shadow-xl space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
          Guiding Architectural Creed
        </span>
        <blockquote className="text-xl sm:text-2xl font-bold text-amber-100/90 italic leading-snug">
          “Scale the infrastructure and the evidence — not an opaque AI decision-maker.”
        </blockquote>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed pt-1">
          JansevaHelp-AI does not replace human administrators with an autonomous algorithm.
          Instead, it empowers citizens to communicate in their native language and equips decision-makers
          with comparable, explainable, and geographic development intelligence.
        </p>
      </div>

      {/* The 4 Digital Public Good (DPG) Principles */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600">Open Standards</span>
          <h2 className="text-2xl font-bold text-slate-900 mt-1">
            Digital Public Good Principles
          </h2>
          <p className="text-xs text-slate-600 mt-1">
            Engineered from day one to evolve into an open, reusable civic infrastructure layer.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* OPENABLE */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 font-black flex items-center justify-center text-sm">
              01
            </div>
            <h3 className="text-lg font-bold text-slate-900">OPENABLE</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              A standardized, open citizen-development request schema that can be freely reused across state governments,
              district collectors, Panchayati Raj institutions, and grassroots NGO programs without proprietary lock-in.
            </p>
          </div>

          {/* MULTILINGUAL */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-800 font-black flex items-center justify-center text-sm">
              02
            </div>
            <h3 className="text-lg font-bold text-slate-900">MULTILINGUAL</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Language should not determine whether a community need becomes visible in planning data.
              Citizens express themselves freely in Marathi, Hindi, English, Gujarati, etc., while the system standardizes intent.
            </p>
          </div>

          {/* EXPLAINABLE */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 font-black flex items-center justify-center text-sm">
              03
            </div>
            <h3 className="text-lg font-bold text-slate-900">EXPLAINABLE</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              No black-box prioritization. The 100-point hotspot signal transparently exposes its mathematical weights:
              Volume (35%), Urgency (25%), Impacted Population (25%), and Baseline Infrastructure Gap (15%).
            </p>
          </div>

          {/* HUMAN-IN-THE-LOOP */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-800 font-black flex items-center justify-center text-sm">
              04
            </div>
            <h3 className="text-lg font-bold text-slate-900">HUMAN-IN-THE-LOOP</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              AI surfaces evidence and proposes project ideas; constitutional institutions and elected representatives retain
              full sovereignty over public budgets, technical audits, and executive sanctions.
            </p>
          </div>
        </div>
      </section>

      {/* Built for India Architecture */}
      <section className="bg-slate-50 p-6 sm:p-8 rounded-3xl border border-slate-200 space-y-4">
        <div className="flex items-center gap-2 text-slate-900 font-bold text-lg">
          <Globe2 className="w-5 h-5 text-amber-600" />
          <span>Designed for India — Not One City</span>
        </div>
        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
          India's civic reality cannot be modeled as a single municipal ticket queue.
          JansevaHelp-AI implements an extensible three-tier data hierarchy:
        </p>
        <div className="flex flex-wrap items-center gap-3 text-xs font-bold text-slate-800 pt-1">
          <span className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 shadow-sm">
            Tier 1: State (e.g. Maharashtra, Assam, Bihar, Rajasthan...)
          </span>
          <span className="text-slate-400">→</span>
          <span className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 shadow-sm">
            Tier 2: District (e.g. Ahmednagar, Guwahati, Barmer...)
          </span>
          <span className="text-slate-400">→</span>
          <span className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 shadow-sm">
            Tier 3: Locality (Taluka, Block, Gram Panchayat, Ward)
          </span>
        </div>
      </section>

      {/* MANDATORY HONESTY AND TRANSPARENCY NOTICE */}
      <section className="bg-amber-50/70 border-2 border-amber-300/80 rounded-3xl p-6 sm:p-8 space-y-3">
        <div className="flex items-center gap-2 text-amber-950 font-extrabold text-sm sm:text-base">
          <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0" />
          <span>Mandatory Prototype Transparency & Honesty Disclosure</span>
        </div>
        <div className="text-xs text-amber-900/90 space-y-2 leading-relaxed font-medium">
          <p>
            • <strong>Prototype:</strong> JansevaHelp-AI is a proof-of-concept prototype built for the <em>Build with AI: Code for Communities — Second Edition</em> hackathon.
          </p>
          <p>
            • <strong>Synthetic / Demo Data:</strong> Demonstration citizen requests and regional infrastructure indicators shown in this prototype are synthetic representations crafted to demonstrate system capabilities. They do NOT represent official government statistics or real-time departmental databases.
          </p>
          <p>
            • <strong>Decision-Support Signal:</strong> Hotspot signals and project recommendations are prototype decision-support metrics, NOT official government rankings, sanctions, or mandates.
          </p>
          <p>
            • <strong>Designed to Scale Across India:</strong> The platform is architecturally ready for integration with open civic platforms and digital public infrastructure (DPI) ecosystems.
          </p>
        </div>
      </section>
    </div>
  );
};
