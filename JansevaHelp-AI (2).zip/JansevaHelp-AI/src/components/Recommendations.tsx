import React, { useState } from 'react';
import { 
  Sparkles, 
  ShieldAlert, 
  ShieldCheck, 
  MapPin, 
  FileText, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  Clock, 
  Download, 
  UserCheck, 
  Compass, 
  ExternalLink,
  Info
} from 'lucide-react';
import { HotspotData, AIRecommendation } from '../types';
import { generateAIRecommendation } from '../services/api';

interface RecommendationsProps {
  hotspots: HotspotData[];
  selectedHotspot?: HotspotData | null;
  onSelectHotspot?: (hotspot: HotspotData) => void;
}

export const Recommendations: React.FC<RecommendationsProps> = ({
  hotspots,
  selectedHotspot: initialSelected,
  onSelectHotspot,
}) => {
  const [currentHotspot, setCurrentHotspot] = useState<HotspotData | null>(
    initialSelected || (hotspots.length > 0 ? hotspots[0] : null)
  );
  const [recommendationsCache, setRecommendationsCache] = useState<Record<string, AIRecommendation>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Human-in-the-loop audit actions state
  const [humanDecisions, setHumanDecisions] = useState<Record<string, { status: string; timestamp: string; officerNote?: string }>>({});
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [officerNoteInput, setOfficerNoteInput] = useState('');

  const activeHotspot = currentHotspot || (hotspots.length > 0 ? hotspots[0] : null);
  const activeRecommendation = activeHotspot ? recommendationsCache[activeHotspot.id] : null;
  const currentDecision = activeHotspot ? humanDecisions[activeHotspot.id] : null;

  const handleGenerate = async (hotspotToRun: HotspotData) => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const rec = await generateAIRecommendation(hotspotToRun);
      setRecommendationsCache((prev) => ({
        ...prev,
        [hotspotToRun.id]: rec,
      }));
    } catch (err: unknown) {
      console.error('Error getting recommendation from Gemini:', err);
      setErrorMessage(
        err instanceof Error ? err.message : 'Failed to generate recommendation. Please retry.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleRecordDecision = (status: string, note?: string) => {
    if (!activeHotspot) return;
    setHumanDecisions((prev) => ({
      ...prev,
      [activeHotspot.id]: {
        status,
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        officerNote: note,
      },
    }));
    setShowNoteModal(false);
    setOfficerNoteInput('');
  };

  return (
    <div className="space-y-8 py-4">
      {/* Header section */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-indigo-50 text-indigo-900 border border-indigo-200 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            <span>Explainable AI Decision Support Layer</span>
          </span>
          <span className="px-2.5 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-200 text-xs font-semibold">
            Human-in-the-Loop Architecture
          </span>
        </div>

        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          AI Development Recommendations
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl leading-relaxed">
          Google Gemini translates aggregated citizen demand evidence and baseline regional indicators into
          transparent, explainable civic project concepts. Every recommendation displays explicit data limitations
          and reserves final administrative authority for human officials.
        </p>
      </div>

      {/* Hotspot Cluster Switcher */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Select a Demand Hotspot to Generate or Review Recommendations:
          </span>
          <span className="text-xs text-slate-400 font-medium">
            {hotspots.length} active demand clusters
          </span>
        </div>

        <div className="flex items-center gap-2.5 overflow-x-auto pb-2 scrollbar-thin">
          {hotspots.map((h) => {
            const isSelected = activeHotspot?.id === h.id;
            const hasCached = Boolean(recommendationsCache[h.id]);

            return (
              <button
                key={h.id}
                onClick={() => {
                  setCurrentHotspot(h);
                  if (onSelectHotspot) onSelectHotspot(h);
                }}
                className={`whitespace-nowrap px-4 py-2.5 rounded-2xl text-xs font-bold transition flex items-center gap-2 border ${
                  isSelected
                    ? 'bg-slate-900 text-white border-slate-900 shadow-md'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                }`}
              >
                <span>{h.district}</span>
                <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                  isSelected ? 'bg-amber-400 text-slate-950' : 'bg-slate-200 text-slate-700'
                }`}>
                  {h.category} • {h.hotspotSignal}
                </span>
                {hasCached && (
                  <CheckCircle2 className={`w-3.5 h-3.5 ${isSelected ? 'text-emerald-400' : 'text-emerald-600'}`} />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Area */}
      {activeHotspot ? (
        <div className="space-y-6">
          {/* Selected Hotspot Context Card */}
          <div className="bg-slate-50 rounded-3xl border border-slate-200 p-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                <MapPin className="w-3.5 h-3.5 text-slate-700" />
                <span>{activeHotspot.state} • {activeHotspot.district}</span>
                <span className="text-slate-300">•</span>
                <span className="text-amber-700">{activeHotspot.category} Sector</span>
              </div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                {activeHotspot.district} — {activeHotspot.category} Priority Cluster
              </h2>
              <p className="text-xs text-slate-600 max-w-2xl">
                Aggregated from {activeHotspot.requestCount} citizen requests ({activeHotspot.highUrgencyCount} high urgency),
                representing ~{activeHotspot.totalAffectedPopulation.toLocaleString('en-IN')} community members with a prototype signal of <strong>{activeHotspot.hotspotSignal}/100</strong>.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => handleGenerate(activeHotspot)}
                disabled={isLoading}
                className="px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:bg-slate-300 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md transition-all hover:scale-[1.02]"
              >
                <Sparkles className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                <span>{isLoading ? 'Generating with Gemini...' : activeRecommendation ? 'Regenerate Recommendation' : 'Generate Recommendation'}</span>
              </button>
            </div>
          </div>

          {/* Loading State Animation */}
          {isLoading && (
            <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-4">
              <Sparkles className="w-8 h-8 text-amber-500 animate-spin mx-auto" />
              <div className="space-y-1">
                <h4 className="font-bold text-slate-900 text-base">Gemini is Synthesizing Aggregated Evidence...</h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Correlating citizen voice excerpts, demographic pressure, baseline regional indicators,
                  and public scheme alignment.
                </p>
              </div>
            </div>
          )}

          {/* Error Message */}
          {errorMessage && (
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* The Explainable Recommendation Card */}
          {activeRecommendation && !isLoading && (
            <div className="bg-white rounded-3xl border border-slate-200 shadow-md overflow-hidden space-y-6 p-6 sm:p-9">
              {/* Mandatory Ethical Framing Banner */}
              <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-amber-900">
                <Compass className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="font-bold">
                    “AI surfaced this as a development priority signal based on available evidence.”
                  </p>
                  <p className="text-[11px] text-amber-800/80">
                    Transparent Decision Support • Final public decisions remain human decisions.
                  </p>
                </div>
              </div>

              {/* Recommendation Title & Scheme */}
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-900 text-white">
                    Project Proposal Concept
                  </span>
                  {activeRecommendation.fundingSchemeAlignment && (
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                      Alignment: {activeRecommendation.fundingSchemeAlignment}
                    </span>
                  )}
                </div>

                <h3 className="text-2xl font-black text-slate-900 leading-snug">
                  {activeRecommendation.recommendedProjectIdea}
                </h3>
              </div>

              {/* Evidence & Need Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                {/* Detected Development Need */}
                <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Detected Development Need
                  </span>
                  <p className="text-sm font-semibold text-slate-900 leading-relaxed">
                    {activeRecommendation.detectedDevelopmentNeed}
                  </p>
                  <div className="pt-2 text-xs text-slate-600">
                    <strong>Primary Stakeholders Affected:</strong> {activeRecommendation.affectedGroups}
                  </div>
                </div>

                {/* Supporting Citizen Evidence */}
                <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Supporting Citizen Evidence
                  </span>
                  <p className="text-sm text-slate-800 leading-relaxed">
                    {activeRecommendation.supportingEvidence}
                  </p>
                  <div className="pt-2 text-xs text-slate-600">
                    <strong>Citizen Voice Excerpts:</strong> {activeHotspot.sampleProblems.slice(0, 2).map(p => `"${p}"`).join('; ')}
                  </div>
                </div>
              </div>

              {/* Reason for Recommendation */}
              <div className="bg-blue-50/50 p-5 rounded-2xl border border-blue-200/80 space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-900">
                  Reason for Recommendation
                </span>
                <p className="text-xs sm:text-sm text-slate-800 leading-relaxed font-medium">
                  {activeRecommendation.reasonForRecommendation}
                </p>
              </div>

              {/* Recommended Phased Interventions */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-slate-900">
                  Recommended Actionable Interventions (District Engineering / ULB / PRI):
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {activeRecommendation.recommendedInterventions.map((step, idx) => (
                    <div key={idx} className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1.5 text-xs">
                      <div className="w-5 h-5 rounded-md bg-amber-500 text-slate-950 font-bold flex items-center justify-center text-[11px]">
                        {idx + 1}
                      </div>
                      <p className="font-semibold text-slate-800">{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Mandatory Relevant Limitations Box */}
              <div className="bg-rose-50/60 p-5 rounded-2xl border border-rose-200/80 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-rose-900">
                  <ShieldAlert className="w-4 h-4 text-rose-600" />
                  <span>Transparent Data Limitations & Caveats (Submitted Deck Requirement)</span>
                </div>
                <p className="text-xs text-rose-900/90 leading-relaxed">
                  {activeRecommendation.relevantLimitations}
                </p>
                <p className="text-[11px] text-rose-800/80 italic pt-1">
                  * Note: Prototype demand signals do not replace statutory Gram Sabha sanctions or technical DPR audits.
                </p>
              </div>

              {/* HUMAN-IN-THE-LOOP DECISION LAYER */}
              <div className="pt-4 border-t border-slate-200 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <UserCheck className="w-4 h-4 text-emerald-600" />
                      <span>Human-in-the-Loop Institutional Decision Record</span>
                    </h4>
                    <p className="text-xs text-slate-500">
                      Administrators record institutional actions on this AI-surfaced priority signal.
                    </p>
                  </div>

                  {currentDecision && (
                    <div className="px-3 py-1 rounded-lg bg-emerald-100 text-emerald-900 font-bold text-xs flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Status: {currentDecision.status} ({currentDecision.timestamp})</span>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => handleRecordDecision('Acknowledged by Planning Wing')}
                    className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition"
                  >
                    ✓ Acknowledge Priority Signal
                  </button>

                  <button
                    onClick={() => handleRecordDecision('Field Verification Audit Dispatched')}
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs transition"
                  >
                    📍 Schedule On-Ground Audit
                  </button>

                  <button
                    onClick={() => setShowNoteModal(true)}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs transition"
                  >
                    ✏️ Add Officer Annotation
                  </button>

                  <button
                    onClick={() => {
                      window.print();
                    }}
                    className="px-4 py-2 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs flex items-center gap-1.5 transition ml-auto"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Print Concept Brief</span>
                  </button>
                </div>

                {currentDecision?.officerNote && (
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-700">
                    <strong>Administrative Note:</strong> {currentDecision.officerNote}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Empty / Prompt State */}
          {!activeRecommendation && !isLoading && (
            <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-4">
              <Sparkles className="w-10 h-10 text-amber-500 mx-auto" />
              <div className="space-y-1">
                <h4 className="font-bold text-slate-900 text-base">
                  No Recommendation Generated Yet for {activeHotspot.district}
                </h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Click the button below to have Google Gemini evaluate the aggregated citizen demand evidence and baseline indicators.
                </p>
              </div>
              <button
                onClick={() => handleGenerate(activeHotspot)}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition"
              >
                <Sparkles className="w-4 h-4" />
                <span>Generate Explainable Recommendation</span>
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="p-12 text-center text-slate-400 text-sm">
          No demand hotspots available. Please submit citizen requests or reset demo data.
        </div>
      )}

      {/* Officer Note Modal */}
      {showNoteModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <h3 className="font-bold text-slate-900 text-base">
              Add Administrative Planning Note
            </h3>
            <p className="text-xs text-slate-500">
              Attach an institutional comment to this decision-support signal for audit trails.
            </p>
            <textarea
              rows={3}
              value={officerNoteInput}
              onChange={(e) => setOfficerNoteInput(e.target.value)}
              placeholder="e.g. Referred to Executive Engineer (PWD Parner Division) for joint site inspection on next Tuesday..."
              className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowNoteModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                onClick={() => handleRecordDecision('Annotated by District Planner', officerNoteInput)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 text-white hover:bg-slate-800"
              >
                Save Note
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
