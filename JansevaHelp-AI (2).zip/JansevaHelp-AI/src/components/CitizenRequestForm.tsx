import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Send, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  Layers, 
  ShieldCheck, 
  MapPin, 
  Languages, 
  Volume2, 
  HelpCircle,
  AlertCircle
} from 'lucide-react';
import { INDIAN_STATES_DISTRICTS } from '../data/geoData';
import { analyzeCitizenRequest, AnalysisResponse } from '../services/api';
import { addCitizenRequest } from '../services/firebase';
import { CitizenRequest } from '../types';

interface CitizenRequestFormProps {
  onSuccessNavigate?: (tab: string) => void;
  prefillMarathi?: boolean;
}

export const CitizenRequestForm: React.FC<CitizenRequestFormProps> = ({
  onSuccessNavigate,
  prefillMarathi = false,
}) => {
  const [requestText, setRequestText] = useState('');
  const [selectedState, setSelectedState] = useState('Maharashtra');
  const [selectedDistrict, setSelectedDistrict] = useState('Ahmednagar');
  const [locality, setLocality] = useState('');
  const [submissionSource, setSubmissionSource] = useState<'text' | 'voice'>('text');

  // Speech Recognition state
  const [isRecording, setIsRecording] = useState(false);
  const [speechLanguage, setSpeechLanguage] = useState<'mr-IN' | 'hi-IN' | 'en-IN' | 'gu-IN' | 'kn-IN'>('mr-IN');
  const [speechSupported, setSpeechSupported] = useState(true);
  const recognitionRef = useRef<any>(null);

  // Submission pipeline state
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [submittedData, setSubmittedData] = useState<{
    originalText: string;
    structured: AnalysisResponse['structured'];
    requestId: string;
  } | null>(null);

  // Dynamic districts based on selected state
  const availableDistricts = INDIAN_STATES_DISTRICTS[selectedState] || ['Central District'];

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = speechLanguage;

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        if (currentTranscript) {
          setRequestText((prev) => (prev ? `${prev} ${currentTranscript}` : currentTranscript));
          setSubmissionSource('voice');
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition warning/error:', event.error);
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      recognitionRef.current = recognition;
    } catch (e) {
      console.warn('Speech recognition setup failed:', e);
      setSpeechSupported(false);
    }
  }, [speechLanguage]);

  // Handle prefill if requested from Home page
  useEffect(() => {
    if (prefillMarathi) {
      handleExampleClick('marathi');
    }
  }, [prefillMarathi]);

  const toggleRecording = () => {
    if (!speechSupported) {
      alert('Browser speech recognition is not supported in this browser. Please use text input below.');
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    } else {
      try {
        setSubmissionSource('voice');
        recognitionRef.current.lang = speechLanguage;
        recognitionRef.current?.start();
        setIsRecording(true);
      } catch (err) {
        console.error('Failed to start voice recognition:', err);
        setIsRecording(false);
      }
    }
  };

  const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newState = e.target.value;
    setSelectedState(newState);
    const districts = INDIAN_STATES_DISTRICTS[newState] || [];
    setSelectedDistrict(districts[0] || '');
  };

  const handleExampleClick = (type: 'marathi' | 'english' | 'hindi') => {
    if (type === 'marathi') {
      setRequestText('आमच्या गावातील रस्ता खराब आहे. पावसाळ्यात शाळेत जाणाऱ्या मुलांना खूप अडचण होते.');
      setSelectedState('Maharashtra');
      setSelectedDistrict('Ahmednagar');
      setLocality('Parner Taluka, Alkuti Village');
      setSpeechLanguage('mr-IN');
    } else if (type === 'english') {
      setRequestText('Our village has poor road access and students face difficulty reaching school during the monsoon.');
      setSelectedState('Maharashtra');
      setSelectedDistrict('Nashik');
      setLocality('Igatpuri Block');
      setSpeechLanguage('en-IN');
    } else if (type === 'hindi') {
      setRequestText('हमारे गांव में पीने के पानी की उचित व्यवस्था नहीं है। बोरवेल से खारा पानी आ रहा है।');
      setSelectedState('Rajasthan');
      setSelectedDistrict('Barmer');
      setLocality('Sheo Tehsil, Dhani');
      setSpeechLanguage('hi-IN');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestText.trim()) {
      setErrorMessage('Please enter your development request or record via voice.');
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    try {
      // Step 1: Call Gemini Understanding Layer
      setProcessingStep('Gemini AI: Detecting language, category, and extracting civic intent...');
      const analysisResult = await analyzeCitizenRequest(
        requestText,
        selectedState,
        selectedDistrict,
        locality,
        submissionSource
      );

      // Step 2: Prepare immutable record
      setProcessingStep('Firestore: Committing structured civic record to real-time database...');
      const structured = analysisResult.structured;

      const recordToStore: Omit<CitizenRequest, 'id'> = {
        originalText: requestText,
        language: structured.language,
        state: structured.state || selectedState,
        district: structured.district || selectedDistrict,
        locality: structured.locality || locality || '',
        category: structured.category,
        problem: structured.problem,
        urgency: structured.urgency,
        affectedGroup: structured.affectedGroup,
        requestedSolution: structured.requestedSolution,
        estimatedAffectedCount: structured.estimatedAffectedCount || 1500,
        source: submissionSource,
        status: structured.urgency === 'High' ? 'Hotspot Flagged' : 'Under Review',
        createdAt: new Date().toISOString(),
      };

      const docId = await addCitizenRequest(recordToStore);

      // Step 3: Success state with dual-view
      setProcessingStep('Real-time sync complete: Live intelligence & hotspot recalculation triggered!');
      setSubmittedData({
        originalText: requestText,
        structured,
        requestId: docId,
      });
    } catch (err: unknown) {
      console.error('Submission pipeline failed:', err);
      setErrorMessage(
        err instanceof Error ? err.message : 'An error occurred during submission. Please try again.'
      );
    } finally {
      setIsProcessing(false);
    }
  };

  const resetForm = () => {
    setRequestText('');
    setSubmittedData(null);
    setErrorMessage(null);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-4">
      {/* Header section */}
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-200 text-xs font-semibold">
          <Languages className="w-3.5 h-3.5 text-amber-600" />
          <span>Multilingual Voice + Text Citizen Interface</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Submit Citizen Development Request
        </h1>
        <p className="text-sm text-slate-600 max-w-2xl leading-relaxed">
          Express your community need in your own words and language.
          Google Gemini extracts the civic structure without changing your original voice,
          feeding into transparent district priority signals.
        </p>
      </div>

      {/* SUCCESS CONFIRMATION DUAL-VIEW (When Submitted) */}
      {submittedData && (
        <div className="bg-white rounded-3xl border-2 border-emerald-500/80 shadow-xl overflow-hidden animate-in fade-in duration-300">
          <div className="bg-emerald-600 text-white p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-bold">Request Successfully Stored to Firestore</h3>
                <p className="text-xs text-emerald-100">
                  Real-time listener updated • Hotspots recalculated • ID: #{submittedData.requestId.slice(-8)}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onSuccessNavigate?.('intelligence')}
                className="px-3.5 py-1.5 rounded-lg bg-white text-emerald-900 font-bold text-xs hover:bg-emerald-50 transition shadow"
              >
                View in Live Feed →
              </button>
            </div>
          </div>

          <div className="p-6 md:p-8 space-y-6">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Core Design Principle: Dual-Preservation View
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left Column: Original Citizen Voice (Unaltered) */}
              <div className="bg-amber-50/60 rounded-2xl p-5 border border-amber-200/80 space-y-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                      <Volume2 className="w-4 h-4 text-amber-700" />
                      Original Citizen Voice (Unaltered)
                    </span>
                    <span className="text-[11px] px-2 py-0.5 rounded font-bold bg-amber-200/70 text-amber-900">
                      {submittedData.structured.language}
                    </span>
                  </div>
                  <p className="text-sm font-medium text-slate-800 italic bg-white/80 p-3.5 rounded-xl border border-amber-100">
                    "{submittedData.originalText}"
                  </p>
                </div>
                <div className="pt-2 text-[11px] text-amber-800/80 flex items-center justify-between">
                  <span>Input Mode: {submissionSource === 'voice' ? '🎙️ Voice Speech-to-Text' : '⌨️ Text'}</span>
                  <span>No PII Collected</span>
                </div>
              </div>

              {/* Right Column: Structured AI Interpretation */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-orange-600" />
                    Structured AI Interpretation (Gemini)
                  </span>
                  <span className={`text-[11px] px-2 py-0.5 rounded font-bold ${
                    submittedData.structured.urgency === 'High'
                      ? 'bg-rose-100 text-rose-800'
                      : submittedData.structured.urgency === 'Medium'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-slate-200 text-slate-800'
                  }`}>
                    {submittedData.structured.urgency} Urgency
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-slate-500 font-medium">Category: </span>
                    <span className="font-bold text-slate-900">{submittedData.structured.category}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 font-medium">Location: </span>
                    <span className="font-semibold text-slate-800">
                      {submittedData.structured.district}, {submittedData.structured.state}
                      {submittedData.structured.locality ? ` • ${submittedData.structured.locality}` : ''}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 font-medium">Extracted Core Problem: </span>
                    <p className="font-medium text-slate-900 mt-0.5 bg-white p-2 rounded-lg border border-slate-200">
                      {submittedData.structured.problem}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500 font-medium">Affected Community: </span>
                    <span className="font-semibold text-slate-800">{submittedData.structured.affectedGroup}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 font-medium">Requested Intervention: </span>
                    <span className="font-semibold text-slate-800">{submittedData.structured.requestedSolution}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Next Steps Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => onSuccessNavigate?.('intelligence')}
                className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm flex items-center gap-2 transition"
              >
                <Layers className="w-4 h-4 text-amber-400" />
                <span>Open Live Intelligence Dashboard</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => onSuccessNavigate?.('hotspots')}
                className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-2 transition"
              >
                <MapPin className="w-4 h-4" />
                <span>See Hotspot Signal Recalculation</span>
              </button>

              <button
                onClick={resetForm}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs sm:text-sm transition"
              >
                Submit Another Need
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Submission Form */}
      {!submittedData && (
        <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm">
          {/* Quick Example Triggers */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              Try 1-Click Multilingual Examples (from concept deck)
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => handleExampleClick('marathi')}
                className="p-3 text-left rounded-xl bg-amber-50/80 hover:bg-amber-100/80 border border-amber-200/90 text-xs transition group"
              >
                <div className="font-bold text-amber-900 flex items-center justify-between">
                  <span>Marathi (Ahmednagar)</span>
                  <span className="text-[10px] text-amber-700">Roads</span>
                </div>
                <p className="text-slate-700 line-clamp-2 mt-1">
                  “आमच्या गावातील रस्ता खराब आहे. पावसाळ्यात शाळेत जाणाऱ्या मुलांना खूप अडचण होते.”
                </p>
              </button>

              <button
                type="button"
                onClick={() => handleExampleClick('english')}
                className="p-3 text-left rounded-xl bg-sky-50/80 hover:bg-sky-100/80 border border-sky-200/90 text-xs transition group"
              >
                <div className="font-bold text-sky-900 flex items-center justify-between">
                  <span>English (Nashik)</span>
                  <span className="text-[10px] text-sky-700">Road Access</span>
                </div>
                <p className="text-slate-700 line-clamp-2 mt-1">
                  “Our village has poor road access and students face difficulty reaching school during monsoon.”
                </p>
              </button>

              <button
                type="button"
                onClick={() => handleExampleClick('hindi')}
                className="p-3 text-left rounded-xl bg-emerald-50/80 hover:bg-emerald-100/80 border border-emerald-200/90 text-xs transition group"
              >
                <div className="font-bold text-emerald-900 flex items-center justify-between">
                  <span>Hindi (Barmer)</span>
                  <span className="text-[10px] text-emerald-700">Water</span>
                </div>
                <p className="text-slate-700 line-clamp-2 mt-1">
                  “हमारे गांव में पीने के पानी की उचित व्यवस्था नहीं है। बोरवेल में खारा पानी आ रहा है।”
                </p>
              </button>
            </div>
          </div>

          {/* Voice Input Controller */}
          <div className="bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-900">Voice Input Option</span>
                <span className="text-[11px] text-slate-500">
                  (Browser Web Speech API)
                </span>
              </div>

              {/* Language selection for speech */}
              <div className="flex items-center gap-2">
                <label className="text-xs text-slate-600 font-medium">Mic Language:</label>
                <select
                  value={speechLanguage}
                  onChange={(e) => setSpeechLanguage(e.target.value as any)}
                  className="text-xs font-semibold bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                >
                  <option value="mr-IN">मराठी (Marathi)</option>
                  <option value="hi-IN">हिन्दी (Hindi)</option>
                  <option value="en-IN">English (India)</option>
                  <option value="gu-IN">ગુજરાતી (Gujarati)</option>
                  <option value="kn-IN">ಕನ್ನಡ (Kannada)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={toggleRecording}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all ${
                  isRecording
                    ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30 animate-pulse'
                    : 'bg-white hover:bg-slate-100 text-slate-900 border border-slate-300 shadow-sm'
                }`}
              >
                {isRecording ? (
                  <>
                    <MicOff className="w-4 h-4 text-white" />
                    <span>Stop Recording</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4 text-amber-600" />
                    <span>Start Voice Recording</span>
                  </>
                )}
              </button>

              {isRecording && (
                <div className="flex items-center gap-2 text-xs text-rose-600 font-semibold animate-pulse">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
                  <span>Listening in {speechLanguage === 'mr-IN' ? 'Marathi' : speechLanguage === 'hi-IN' ? 'Hindi' : 'English'}... Speak now</span>
                </div>
              )}

              {!isRecording && (
                <span className="text-xs text-slate-500 hidden sm:inline">
                  Speak naturally in Marathi, Hindi, English, etc.
                </span>
              )}
            </div>
          </div>

          {/* Citizen Request Textarea */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-slate-900">
                Citizen Request <span className="text-rose-500">*</span>
              </label>
              <span className="text-xs text-slate-400">
                Type or speak in your own language
              </span>
            </div>
            <textarea
              rows={4}
              required
              value={requestText}
              onChange={(e) => {
                setRequestText(e.target.value);
                setSubmissionSource('text');
              }}
              placeholder="वर्णन करा किंवा लिहा: Describe your village or ward issue (e.g. road damage, missing water pipeline, health clinic absence, school power cuts)..."
              className="w-full rounded-2xl border border-slate-300 p-4 text-sm text-slate-900 focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20 font-sans leading-relaxed"
            />
          </div>

          {/* Geographic Location Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                State <span className="text-rose-500">*</span>
              </label>
              <select
                value={selectedState}
                onChange={handleStateChange}
                className="w-full text-xs sm:text-sm font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
              >
                {Object.keys(INDIAN_STATES_DISTRICTS).map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                District <span className="text-rose-500">*</span>
              </label>
              <select
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
                className="w-full text-xs sm:text-sm font-semibold bg-white border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
              >
                {availableDistricts.map((dst) => (
                  <option key={dst} value={dst}>
                    {dst}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">
                Locality / Village / Ward <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <input
                type="text"
                value={locality}
                onChange={(e) => setLocality(e.target.value)}
                placeholder="e.g. Parner Alkuti, Ward 12"
                className="w-full text-xs sm:text-sm bg-white border border-slate-300 rounded-xl px-3 py-2.5 text-slate-900 focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
              />
            </div>
          </div>

          {/* Privacy & No PII Note */}
          <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              <strong>Zero PII Required:</strong> We do not ask for your phone number, Aadhaar, or email. Your civic request is processed anonymously to protect community privacy.
            </span>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Processing Animation */}
          {isProcessing && (
            <div className="bg-amber-50/70 border border-amber-200 p-4 rounded-2xl space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
                <Sparkles className="w-4 h-4 text-amber-600 animate-spin" />
                <span>{processingStep}</span>
              </div>
              <div className="w-full bg-amber-200/50 h-1.5 rounded-full overflow-hidden">
                <div className="bg-amber-600 h-full w-2/3 animate-pulse rounded-full" />
              </div>
            </div>
          )}

          {/* Submit Action */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="submit"
              disabled={isProcessing || !requestText.trim()}
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-bold text-sm shadow-md transition-all hover:scale-[1.01] active:scale-[0.99]"
            >
              <Send className="w-4 h-4 text-amber-400" />
              <span>{isProcessing ? 'Analyzing with Gemini...' : 'Submit to Development Layer'}</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
