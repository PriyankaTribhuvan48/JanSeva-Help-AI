import { initializeApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  onSnapshot,
  query,
  limit,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { CitizenRequest } from '../types';
import { SEED_CITIZEN_REQUESTS } from '../data/seedRequests';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: true,
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  return errInfo;
}

// Initialize Firebase App
export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

const COLLECTION_NAME = 'citizen_requests';

/**
 * Real-time listener for citizen requests
 */
export function subscribeToCitizenRequests(
  onData: (requests: CitizenRequest[]) => void,
  onError?: (err: unknown) => void
) {
  try {
    const q = query(collection(db, COLLECTION_NAME));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: CitizenRequest[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          items.push({
            id: docSnap.id,
            originalText: data.originalText || '',
            language: data.language || 'English',
            state: data.state || 'Maharashtra',
            district: data.district || 'Ahmednagar',
            locality: data.locality || '',
            category: data.category || 'Roads',
            problem: data.problem || '',
            urgency: data.urgency || 'Medium',
            affectedGroup: data.affectedGroup || '',
            requestedSolution: data.requestedSolution || '',
            estimatedAffectedCount: Number(data.estimatedAffectedCount) || 1000,
            source: data.source || 'text',
            status: data.status || 'Under Review',
            createdAt: data.createdAt || new Date().toISOString(),
          });
        });

        // Sort descending by creation date
        items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        onData(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.GET, COLLECTION_NAME);
        if (onError) onError(error);
      }
    );

    return unsubscribe;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, COLLECTION_NAME);
    if (onError) onError(error);
    return () => {};
  }
}

/**
 * Add a new citizen request to Firestore
 */
export async function addCitizenRequest(data: Omit<CitizenRequest, 'id'>): Promise<string> {
  const customId = `req_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  try {
    const docRef = doc(db, COLLECTION_NAME, customId);
    await setDoc(docRef, {
      originalText: data.originalText,
      language: data.language,
      state: data.state,
      district: data.district,
      locality: data.locality || '',
      category: data.category,
      problem: data.problem,
      urgency: data.urgency,
      affectedGroup: data.affectedGroup || '',
      requestedSolution: data.requestedSolution || '',
      estimatedAffectedCount: data.estimatedAffectedCount,
      source: data.source,
      status: data.status,
      createdAt: data.createdAt || new Date().toISOString(),
    });
    return customId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `${COLLECTION_NAME}/${customId}`);
    throw error;
  }
}

/**
 * Seed initial realistic prototype requests if database is empty
 */
export async function seedInitialRequestsIfEmpty(): Promise<number> {
  try {
    const snapshot = await getDocs(query(collection(db, COLLECTION_NAME), limit(1)));
    if (snapshot.empty) {
      console.log('Seeding initial synthetic citizen requests across India...');
      let count = 0;
      for (const item of SEED_CITIZEN_REQUESTS) {
        const id = `seed_${Date.now()}_${count}_${Math.random().toString(36).substring(2, 6)}`;
        await setDoc(doc(db, COLLECTION_NAME, id), item);
        count++;
      }
      return count;
    }
    return snapshot.size;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, COLLECTION_NAME);
    return 0;
  }
}

/**
 * Force re-seed prototype data (useful for demonstration and reset)
 */
export async function forceReseedRequests(): Promise<number> {
  try {
    let count = 0;
    for (const item of SEED_CITIZEN_REQUESTS) {
      const id = `seed_${Date.now()}_${count}_${Math.random().toString(36).substring(2, 6)}`;
      await setDoc(doc(db, COLLECTION_NAME, id), item);
      count++;
    }
    return count;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, COLLECTION_NAME);
    throw error;
  }
}
