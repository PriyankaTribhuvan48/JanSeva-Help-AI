import { HotspotData, AIRecommendation } from '../types';

export interface AnalysisResponse {
  success: boolean;
  originalText: string;
  structured: {
    language: string;
    category: string;
    state: string;
    district: string;
    locality: string;
    problem: string;
    urgency: 'Low' | 'Medium' | 'High';
    affectedGroup: string;
    requestedSolution: string;
    estimatedAffectedCount: number;
    keyPhrases?: string[];
  };
}

export async function analyzeCitizenRequest(
  originalText: string,
  userState?: string,
  userDistrict?: string,
  userLocality?: string,
  source: 'text' | 'voice' = 'text'
): Promise<AnalysisResponse> {
  const res = await fetch('/api/analyze-request', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      originalText,
      userState,
      userDistrict,
      userLocality,
      source,
    }),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Server returned ${res.status}`);
  }

  return res.json();
}

export async function generateAIRecommendation(hotspot: HotspotData): Promise<AIRecommendation> {
  const res = await fetch('/api/generate-recommendation', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      district: hotspot.district,
      state: hotspot.state,
      category: hotspot.category,
      hotspotSignal: hotspot.hotspotSignal,
      requestCount: hotspot.requestCount,
      highUrgencyCount: hotspot.highUrgencyCount,
      affectedPopulation: hotspot.totalAffectedPopulation,
      infrastructureGapScore: hotspot.infrastructureGapScore,
      sampleProblems: hotspot.sampleProblems,
      affectedGroups: hotspot.affectedGroups,
      languagesRepresented: hotspot.languages,
    }),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Server returned ${res.status}`);
  }

  const data = await res.json();
  return {
    ...data.recommendation,
    id: `rec_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
  };
}
