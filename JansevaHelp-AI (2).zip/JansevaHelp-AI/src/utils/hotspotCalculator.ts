import { CitizenRequest, HotspotData } from '../types';

// Baseline synthetic infrastructure gaps for districts
const DISTRICT_GAP_LOOKUP: Record<string, Record<string, number>> = {
  'Ahmednagar': {
    'Roads': 84,
    'Water': 80,
    'Healthcare': 66,
    'Education': 55,
    'Electricity': 50,
    'Sanitation': 62,
    'Public Transport': 72,
    'Digital Connectivity': 58,
  },
  'Nashik': {
    'Roads': 62,
    'Water': 86,
    'Healthcare': 58,
    'Education': 48,
    'Electricity': 45,
    'Sanitation': 64,
    'Public Transport': 60,
    'Digital Connectivity': 50,
  },
  'Guwahati (Kamrup Metro)': {
    'Healthcare': 85,
    'Roads': 70,
    'Water': 75,
    'Education': 60,
    'Electricity': 64,
    'Sanitation': 80,
    'Public Transport': 68,
    'Digital Connectivity': 62,
  },
  'Barmer': {
    'Water': 94,
    'Roads': 76,
    'Healthcare': 82,
    'Education': 70,
    'Electricity': 68,
    'Sanitation': 78,
    'Public Transport': 82,
    'Digital Connectivity': 67,
  },
  'Varanasi': {
    'Healthcare': 80,
    'Sanitation': 82,
    'Roads': 72,
    'Water': 68,
    'Education': 65,
    'Electricity': 54,
    'Public Transport': 71,
    'Digital Connectivity': 52,
  },
  'Patna': {
    'Education': 86,
    'Healthcare': 84,
    'Roads': 74,
    'Water': 72,
    'Electricity': 60,
    'Sanitation': 85,
    'Public Transport': 77,
    'Digital Connectivity': 68,
  },
  'Kutch': {
    'Water': 92,
    'Roads': 65,
    'Healthcare': 73,
    'Education': 62,
    'Electricity': 48,
    'Sanitation': 70,
    'Public Transport': 75,
    'Digital Connectivity': 60,
  },
  'Raichur': {
    'Education': 75,
    'Electricity': 78,
    'Water': 85,
    'Roads': 70,
    'Healthcare': 78,
    'Sanitation': 72,
    'Public Transport': 69,
    'Digital Connectivity': 64,
  },
  'Jhabua': {
    'Electricity': 86,
    'Water': 88,
    'Roads': 80,
    'Healthcare': 85,
    'Education': 77,
    'Sanitation': 82,
    'Public Transport': 78,
    'Digital Connectivity': 73,
  },
  'Kalahandi': {
    'Water': 89,
    'Roads': 79,
    'Healthcare': 84,
    'Education': 72,
    'Electricity': 67,
    'Sanitation': 83,
    'Public Transport': 80,
    'Digital Connectivity': 75,
  },
  'Dharmapuri': {
    'Healthcare': 72,
    'Water': 81,
    'Roads': 58,
    'Education': 50,
    'Electricity': 44,
    'Sanitation': 62,
    'Public Transport': 56,
    'Digital Connectivity': 49,
  },
  'Mahabubnagar': {
    'Public Transport': 74,
    'Water': 77,
    'Roads': 63,
    'Healthcare': 68,
    'Education': 59,
    'Electricity': 47,
    'Sanitation': 66,
    'Digital Connectivity': 53,
  },
  'Purulia': {
    'Education': 82,
    'Digital Connectivity': 80,
    'Water': 88,
    'Roads': 75,
    'Healthcare': 80,
    'Electricity': 62,
    'Sanitation': 79,
    'Public Transport': 74,
  },
};

/**
 * Calculates transparent 100-point prototype hotspot signal based on application data:
 * - Request Volume = 35%
 * - Urgency = 25%
 * - Affected Population = 25%
 * - Infrastructure Gap = 15%
 */
export function calculateHotspots(requests: CitizenRequest[]): HotspotData[] {
  if (!requests || requests.length === 0) return [];

  // Group by District + Category
  const clusterMap: Record<string, {
    district: string;
    state: string;
    category: string;
    requests: CitizenRequest[];
  }> = {};

  for (const req of requests) {
    const key = `${req.district}:::${req.category}`;
    if (!clusterMap[key]) {
      clusterMap[key] = {
        district: req.district,
        state: req.state,
        category: req.category,
        requests: [],
      };
    }
    clusterMap[key].requests.push(req);
  }

  const clusters = Object.values(clusterMap);

  // Determine maximum volume across clusters for normalized scaling
  const maxVolume = Math.max(...clusters.map((c) => c.requests.length), 1);
  const maxPopulation = Math.max(
    ...clusters.map((c) =>
      c.requests.reduce((sum, r) => sum + (r.estimatedAffectedCount || 1000), 0)
    ),
    10000
  );

  const hotspots: HotspotData[] = clusters.map((cluster) => {
    const count = cluster.requests.length;
    const highUrgencyCount = cluster.requests.filter((r) => r.urgency === 'High').length;
    const mediumUrgencyCount = cluster.requests.filter((r) => r.urgency === 'Medium').length;
    const lowUrgencyCount = cluster.requests.filter((r) => r.urgency === 'Low').length;

    const totalAffectedPopulation = cluster.requests.reduce(
      (sum, r) => sum + (r.estimatedAffectedCount || 1000),
      0
    );

    // Baseline synthetic infrastructure gap (0-100)
    const districtGaps = DISTRICT_GAP_LOOKUP[cluster.district] || {};
    const infrastructureGapScore = districtGaps[cluster.category] || 65;

    // Component 1: Request Volume (0-100)
    // Scaled against maximum volume with progressive weighting
    const volumeScore = Math.min(100, Math.round((count / maxVolume) * 85 + (count > 1 ? 15 : 10)));

    // Component 2: Urgency (0-100)
    // High = 100%, Medium = 60%, Low = 25%
    const weightedUrgency =
      (highUrgencyCount * 1.0 + mediumUrgencyCount * 0.6 + lowUrgencyCount * 0.25) / count;
    const urgencyScore = Math.min(100, Math.round(weightedUrgency * 100));

    // Component 3: Affected Population (0-100)
    // Log-normalized scale for realistic civic population bounds
    const popRatio = Math.min(1, Math.log10(totalAffectedPopulation + 10) / Math.log10(maxPopulation * 1.5));
    const populationScore = Math.min(100, Math.max(20, Math.round(popRatio * 100)));

    // Component 4: Infrastructure Gap (0-100)
    const gapScore = infrastructureGapScore;

    // Weighted Formula:
    // Volume: 35% | Urgency: 25% | Population: 25% | Gap: 15%
    const hotspotSignal = Math.min(
      99,
      Math.max(
        15,
        Math.round(
          volumeScore * 0.35 +
          urgencyScore * 0.25 +
          populationScore * 0.25 +
          gapScore * 0.15
        )
      )
    );

    const sampleProblems = Array.from(
      new Set(cluster.requests.map((r) => r.problem || r.originalText.slice(0, 100)))
    ).slice(0, 3);

    const affectedGroups = Array.from(
      new Set(
        cluster.requests
          .map((r) => r.affectedGroup)
          .filter((g): g is string => Boolean(g && g.trim()))
      )
    ).slice(0, 3);

    const languages = Array.from(new Set(cluster.requests.map((r) => r.language)));

    const latestTimestamp = cluster.requests
      .map((r) => r.createdAt)
      .sort()
      .reverse()[0] || new Date().toISOString();

    return {
      id: `${cluster.state}-${cluster.district}-${cluster.category}`.toLowerCase().replace(/[^a-z0-9]/g, '-'),
      district: cluster.district,
      state: cluster.state,
      category: cluster.category,
      requestCount: count,
      highUrgencyCount,
      mediumUrgencyCount,
      lowUrgencyCount,
      totalAffectedPopulation,
      infrastructureGapScore,
      volumeScore,
      urgencyScore,
      populationScore,
      gapScore,
      hotspotSignal,
      sampleProblems,
      affectedGroups,
      languages,
      latestTimestamp,
    };
  });

  // Sort descending by hotspot signal score
  return hotspots.sort((a, b) => b.hotspotSignal - a.hotspotSignal);
}
